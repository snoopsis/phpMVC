<?php
//DB Params
define('DB_HOST', '127.0.0.1');
define('DB_USER', '_YOUR_USER_');
define('DB_PASS', '_YOU_PASS_');
define('DB_NAME', '_DATABASE_');

// App Root
define('APPROOT', dirname(dirname(__FILE__)));
// URL Root
define('URLROOT', '_YOUR_URL_');
// Site Name
define('SITENAME', '_YOU_SITENAME_');