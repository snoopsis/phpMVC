# TraversyMVC

This is a simple PHP MVC framework which is taught as part of Brad Traversy's [Object Oriented PHP & MVC course](https://www.udemy.com/object-oriented-php-mvc/) at Udemy.

1 - Change the data in .htaccess file

2 - Change the config.php with data for my site
