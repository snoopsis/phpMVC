<?php
//DB Params
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'shareposts');

// App Root
define('APPROOT', dirname(dirname(__FILE__)));
// URL Root
define('URLROOT', 'http://localhost/curso-php');
// Site Name
define('SITENAME', 'SharePosts');
// App version
define('APPVERSION', '1.0.0');